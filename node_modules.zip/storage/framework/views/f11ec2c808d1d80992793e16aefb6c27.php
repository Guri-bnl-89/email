<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>

  <!-- ** Basic Page Needs ** -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo e(config('app.title')); ?></title>

  <!--== bootstrap -->
  <link href="<?php echo e(asset('assets/front/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />

  <!--== animate -->
  <link href="<?php echo e(asset('assets/front/css/animate.css')); ?>" rel="stylesheet" type="text/css" />

  <!--== line-awesome -->
  <link href="<?php echo e(asset('assets/front/css/line-awesome.min.css')); ?>" rel="stylesheet" type="text/css" />

  <!--== themify-icons -->
  <link href="<?php echo e(asset('assets/front/css/themify-icons.css')); ?>" rel="stylesheet" type="text/css" />

  <!--== magnific-popup -->
  <link href="<?php echo e(asset('assets/front/css/magnific-popup.css')); ?>" rel="stylesheet" type="text/css" />

  <!--== owl.carousel -->
  <link href="<?php echo e(asset('assets/front/css/owl.carousel.css')); ?>" rel="stylesheet" type="text/css" />

  <!--== lightslider -->
  <link href="<?php echo e(asset('assets/front/css/lightslider.min.css')); ?>" rel="stylesheet" type="text/css" />

  <!--== spacing -->
  <link href="<?php echo e(asset('assets/front/css/spacing.css')); ?>" rel="stylesheet" type="text/css" />

  <!--== theme.min -->
  <link href="<?php echo e(asset('assets/front/css/theme.min.css')); ?>" rel="stylesheet" />

  <link href="<?php echo e(asset('assets/front/css/style.css')); ?>" rel="stylesheet" />

  <!-- inject css end -->
  
  <!--Favicon-->
  <link rel="icon" href="<?php echo e(asset('assets/front/images/favicon.png')); ?>" type="image/x-icon">

</head>

<body>

<!-- page wrapper start -->

<div class="page-wrapper">
  
<!-- preloader start -->

<div id="ht-preloader">
  <div class="loader clear-loader">
    <span></span>
    <p>EmailValidation</p>
  </div>
</div>

<!-- preloader end -->


<!--header start-->

<header class="site-header">
  <div id="header-wrap">
    <div class="container">
      <div class="row">
        <!--menu start-->
        <div class="col"> 
          <nav class="navbar navbar-expand-lg navbar-light">
            <a class="navbar-brand logo text-dark h2 mb-0" href="<?php echo e(route('front')); ?>">
              Email<span class="text-primary fw-bold">Validation</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
              <ul class="navbar-nav ms-auto">
                <li class="nav-item"> 
                  <a class="nav-link <?php echo e(Request::is('front') || Request::is('/') ? 'active' : ''); ?>" href="<?php echo e(route('front')); ?>">Home</a>          
                </li>
                <li class="nav-item"> 
                  <a class="nav-link <?php echo e(Request::is('about-us') ? 'active' : ''); ?>" href="<?php echo e(route('about-us')); ?>">About Us</a>          
                </li>
                <li class="nav-item"> 
                  <a class="nav-link <?php echo e(Request::is('pricing') ? 'active' : ''); ?>" href="<?php echo e(route('pricing')); ?>">Pricing</a>          
                </li>
                <li class="nav-item"> 
                  <a class="nav-link <?php echo e(Request::is('contact') ? 'active' : ''); ?>" href="<?php echo e(route('contact')); ?>">Contact</a>          
                </li>
                <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item"> 
                  <a class="nav-link <?php echo e(Request::is('login') ? 'active' : ''); ?>" href="<?php echo e(route('login')); ?>">Login</a>          
                </li>
                <?php endif; ?>
               
              </ul>
              <?php if(auth()->guard()->guest()): ?>
                <div class="my-2 my-md-0 ml-lg-4 text-center">
                  <a href="<?php echo e(route('register')); ?>" class="btn btn-primary">Register</a>
                </div>
              <?php else: ?>
                <div class="my-2 my-md-0 ml-lg-4 text-center">
                  <a href="<?php echo e(route('login')); ?>" class="btn btn-primary">Dashboard</a>
                </div>
              <?php endif; ?>
            </div>
          </nav>  
        </div>
        <!--menu end-->
      </div>
    </div>
  </div>
</header>

<!--header end--><?php /**PATH C:\wamp64\www\EmailValidation\resources\views/home/layouts/header.blade.php ENDPATH**/ ?>