<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main id="main" class="main">

<div class="pagetitle">
  <h1>List Validation</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
      <li class="breadcrumb-item active">List Validation</li>
    </ol>
  </nav>
</div><!-- End Page Title -->

<section class="section">
  <div class="row">
    <div class="col-lg-4">

      <div class="card">
        <div class="card-body">
          <h5 class="card-title pb-0">Enter Email(s) to Verify</h5>
          <p class="paragraph-text">Validation costs 1 credit per email. Enter up to 10 emails, separated by commas or on their own line.</p>
          <form method="post" action="#">
            <textarea class="form-control" placeholder="Enter email(s)" name="email" rows="8"></textarea>
            <div class="col-12 mt-3">
              <button class="btn btn-primary" type="submit">Validate</button>
            </div>
          </form>
        </div>
      </div>

    </div>

    <div class="col-lg-8">

      <div class="card">
        <div class="card-body">

          <div class="d-flex pb-3">
            <div class="card-title pb-0 text-start flex-grow-1">Result History</div>
            <div class="right-div mt-3">
              <button class="btn btn-sm btn-primary float-end" id="export-to-csv">Export to CSV</button>
            </div>
          </div>


          <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">Email</th>
                    <th scope="col">Result</th>
                    <th scope="col">Time</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Hardimann@mail.com</td>
                    <td>Valid</td>
                    <td>0.58</td>
                  </tr>
                  <tr>
                    <td>rrrrttt@ffff.com</td>
                    <td>Invalid</td>
                    <td>0.40</td>
                  </tr>
                  
                </tbody>
              </table>
        </div>
      </div>

    </div>
  </div>
</section>

</main><!-- End #main -->



<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\EmailValidation\resources\views/pages/listvalidation.blade.php ENDPATH**/ ?>