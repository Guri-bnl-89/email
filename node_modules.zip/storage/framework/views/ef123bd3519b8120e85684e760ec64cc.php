<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <!-- ** Basic Page Needs ** -->
        <meta charset="utf-8">
        <title><?php echo e(config('app.title')); ?></title>

        <!-- bootstrap.min css -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/front/plugins/bootstrap/bootstrap.min.css')); ?>">
        <!-- Icon Font Css -->

        <link rel="stylesheet" href="<?php echo e(asset('assets/front/plugins/fontawesome/css/all.min.css')); ?>">

        <!-- Main Stylesheet -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/style.css')); ?>">

        <!--Favicon-->
        <link rel="icon" href="<?php echo e(asset('assets/front/images/favicon.png')); ?>" type="image/x-icon">
    </head>

    <body>

        <section class="vh-100 gradient-custom">
            <div class="container py-5 h-100">
                <div class="row d-flex justify-content-center align-items-center h-100">
                    <div class="col-12 col-md-8 col-lg-6 col-xl-5">
                        <div class="card bg-dark text-white" style="border-radius: 1rem;">
                            <div class="card-body p-5 text-center">
                                <form method="POST" action="<?php echo e(route('login')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="mb-md-4 mt-md-4">
                                        <h1 class="mb-2 main-text text-md text-uppercase">
                                            Log<span>in</span>
                                        </h1>
                                        <p class="text-white-50 mb-4">Please enter your Email and password!</p>

                                        <div class="form-outline form-white mb-4 text-left">
                                            <label for="email" class="form-label"><?php echo e(__('Email Address')); ?></label>
                                            <input type="email" id="email" class="form-control form-control-lg <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus />
                                            
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                                        </div>
                                        
                                        

                                        <div class="form-outline form-white mb-4 text-left">
                                            <label class="form-label" for="password"><?php echo e(__('Password')); ?></label>
                                            <input id="password" type="password" class="form-control form-control-lg <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>               

                                        

                                        <button class="btn btn-main btn-lg px-5 text-sm" type="submit">Login</button>
                                        <!-- 
                                        <div class="d-flex justify-content-center text-center mt-4 pt-1">
                                        <a href="#!" class="text-white"><i class="fab fa-facebook-f fa-lg"></i></a>
                                        <a href="#!" class="text-white"><i class="fab fa-twitter fa-lg mx-4 px-2"></i></a>
                                        <a href="#!" class="text-white"><i class="fab fa-google fa-lg"></i></a>
                                        </div> -->

                                    </div>
                                </form>

                                <div>
                                    <p class="mb-0"><a class="on-link text-white-50" href="<?php echo e(route('forgot-password')); ?>">Forgot password?</a></p>
                                    <p class="mb-0">Don't have an account? <a href="<?php echo e(route('signup')); ?>" class="on-link text-white-50 font-weight-bold">SignUp</a></p>
                                    <p class="mb-0"><a class="on-link text-white-50" href="<?php echo e(route('home')); ?>"><i class="btn-icon fa fa-arrow-left ml-2"></i> Back to home</a></p>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


    <!-- 
    Essential Scripts
    =====================================-->
    <!-- Main jQuery -->
    <script src="<?php echo e(asset('assets/front/plugins/jquery/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 4.3.1 -->
    <script src="<?php echo e(asset('assets/front/plugins/bootstrap/bootstrap.min.js')); ?>"></script>

    </body>

</html>
<?php /**PATH C:\wamp64\www\EmailValidation\resources\views/home/login.blade.php ENDPATH**/ ?>