

<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
  <h1>Purchase</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
      <li class="breadcrumb-item active">Purchase</li>
    </ol>
  </nav>
</div><!-- End Page Title -->

<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <?php echo e(session('success')); ?>

      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>  
  <?php endif; ?>

  <?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <?php echo e(session('error')); ?>

      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>  
  <?php endif; ?>

<section class="section mb-2">
<?php if(auth()->user()->access == 'admin'): ?>
  <div class="row">
    <div class="col-12 text-end">
      <button type="button" id="add-button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#add-plan">
        <i class="bi bi-clipboard2-plus"></i> Add Plan
      </button>
    </div>
  </div>

  <div class="modal fade" id="add-plan" tabindex="-1" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Add New Plan</h5>
          <button type="button" class="btn-close fs-25" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">

          <div class="row">
            <div class="col-lg-12 px-4 pb-3">
              <form method="POST" id="plan-form" action="<?php echo e(route('addPlan')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="plan-id" name="pid" value="">
                <div class="mb-3">
                  <label for="plan-credits" class="form-label">Credits</label>
                  <input type="text" class="form-control" name="credits" id="plan-credits" value="" required>
                </div>
                <div class="mb-3">
                  <label for="plan-price" class="form-label">Price</label>
                  <input type="text" class="form-control" name="price" id="plan-price" required>
                </div>
                <div class="mb-3">
                  <label for="plan-per-verification" class="form-label">Per Verification</label>
                  <input type="text" class="form-control" name="per_verification" id="plan-per-verification" required>
                </div>
                <div class="col-12 mt-3 text-end">
                  <button class="btn btn-primary" id="plan-button" type="submit">Create</button>
                </div>
              </form>
            </div>
          </div>


        </div>
        
      </div>
    </div>
  </div>
  <?php endif; ?>
</section>

<section class="section">
  <div class="row">
    <div class="col-lg-12">   

      <div class="card">
        <div class="card-body">
          <div class="row justify-content-center pt-5">
            <div class="col-lg-12 text-center">
              <h4>Pay As You Go - Choose Higher Plans for Maximum Savings! </h4>
              <p class="paragraph-text py-2">Never Fear, Credits Never Expire - Use Anytime!</p>
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">Credits</th>
                    <th scope="col">Per Verification</th>
                    <th scope="col">Price</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td id="credit-<?php echo e($key); ?>" data-val="<?php echo e($plan->credits); ?>"><?php echo e(number_format($plan->credits)); ?></td>
                    <td id="verification-<?php echo e($key); ?>" data-val="<?php echo e($plan->per_verification); ?>">$<?php echo e($plan->per_verification); ?></td>
                    <td id="price-<?php echo e($key); ?>" data-val="<?php echo e($plan->price); ?>">$<?php echo e($plan->price); ?></td>
                    <td>
                      <a href="<?php echo e(url('checkout/'.$plan->id)); ?>" class="btn btn-sm btn-primary"><i class="bi bi-cart-check-fill"></i> Buy</a>
                      <?php if(auth()->user()->access == 'admin'): ?>
                      <a id="edit-button" data-key="<?php echo e($key); ?>" data-id="<?php echo e($plan->id); ?>" class="btn btn-sm btn-secondary"><i class="bi bi-pencil-square"></i> Edit</a>
                      <a href="<?php echo e(url('deletePlan/'.$plan->id)); ?>"  onclick="return confirm('Are you sure want to delete?')" class="btn btn-sm btn-danger"><i class="bi bi-trash3-fill"></i> Delete</a>
                      <?php endif; ?>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                </tbody>
              </table>
            </div>
          </div>


          
        </div>
      </div>

    </div>
  </div>
</section>

</main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('cust_scripts'); ?>
  <script>
    $(document).ready(function() {

      $(document).on('click','#edit-button',function(){
        var key = $(this).attr("data-key");
        var pid = $(this).attr("data-id");
        var credit = $('#credit-'+key).attr("data-val");
        var verification = $('#verification-'+key).attr("data-val");
        var price = $('#price-'+key).attr("data-val");
        $('#plan-id').val(pid);
        $('#plan-form').attr('action', "<?php echo e(url('/editPlan')); ?>");
        $('.modal-title').text('Edit Plan');
        $('#plan-credits').val(credit);
        $('#plan-price').val(price);
        $('#plan-per-verification').val(verification);
        $('#plan-button').text('Update');
        $('#add-plan').modal('show');
      });

      $(document).on('click','#add-button',function(){
        $('#plan-id').val('');
        $('#plan-form').attr('action', "<?php echo e(url('/addPlan')); ?>");
        $('.modal-title').text('Add New Plan');
        $('#plan-credits').val('');
        $('#plan-price').val('');
        $('#plan-per-verification').val('');
        $('#plan-button').text('Create');
      });


    });

  </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\EmailValidation\resources\views/pages/credit_purchase.blade.php ENDPATH**/ ?>