
<!--footer start-->

<footer class="py-11 bg-primary position-relative" data-bg-img="assets/front/images/bg/03.png">
  <div class="shape-1" style="height: 150px; overflow: hidden;">
    <svg viewBox="0 0 500 150" preserveAspectRatio="none" style="height: 100%; width: 100%;">
      <path d="M0.00,49.98 C150.00,150.00 271.49,-50.00 500.00,49.98 L500.00,0.00 L0.00,0.00 Z" style="stroke: none; fill: #fff;"></path>
    </svg>
  </div>
  <div class="container mt-7">
    <div class="row">
      <div class="col-12 col-lg-5 col-xl-4 me-auto mb-6 mb-lg-0">
        <div class="subscribe-form p-5">
          <div>
            <a class="footer-logo text-white h4 mb-0" href="<?php echo e(route('front')); ?>">
            Email<span class="fw-bold">Validation</span>
            </a>
          </div>
          <p class="text-light pt-2">We recognize the pivotal role that accurate email data plays in establishing effective and trustworthy communication. Our mission is to provide advanced email validation solutions that go beyond just verification, ensuring your digital interactions are not only efficient but built on a foundation of reliability.</p>
          
        </div>
      </div>
      <div class="col-12 col-lg-6 col-xl-7">
        <div class="row">
          <div class="col-12 col-sm-4 navbar-dark">
            <h5 class="mb-4 text-white">Pages</h5>
            <ul class="navbar-nav list-unstyled mb-0">
              <li class="mb-3 nav-item"><a class="nav-link" href="<?php echo e(route('about-us')); ?>">About</a>
              </li>
              <li class="mb-3 nav-item">
                <a class="nav-link" href="<?php echo e(route('features')); ?>">Features</a>
              </li>

              <li class="mb-3 nav-item"><a class="nav-link" href="<?php echo e(route('blog')); ?>">Blogs</a>
              </li>
              <li class="mb-3 nav-item"><a class="nav-link" href="<?php echo e(route('contact')); ?>">Contact Us</a>
              </li>
              <li class="mb-3 nav-item"><a class="nav-link" href="<?php echo e(route('pricing')); ?>">Pricing</a>
              </li>

              <li class="nav-item"><a class="nav-link" href="<?php echo e(route('faqs')); ?>">Faq</a>
              </li>
            </ul>

          </div>
          <div class="col-12 col-sm-4 mt-6 mt-sm-0 navbar-dark">
          <h5 class="mb-4 text-white">Legal</h5>
            <ul class="navbar-nav list-unstyled mb-0">
              <li class="mb-3 nav-item">
                <a class="nav-link" href="<?php echo e(route('tos')); ?>">Term Of Service</a>
              </li>
              <li class="mb-3 nav-item">
                <a class="nav-link" href="<?php echo e(route('privacy')); ?>">Privacy Policy</a>
              </li>
              <li class="mb-3 nav-item">
                <a class="nav-link" href="<?php echo e(route('data-policy')); ?>">Data Policy</a>
              </li>
              <li class="mb-3 nav-item">
                <a class="nav-link" href="<?php echo e(route('cookie-policy')); ?>">Cookie Policy</a>
              </li>
              <li class="mb-3 nav-item">
                <a class="nav-link" href="<?php echo e(route('refund-policy')); ?>">Refund Policy</a>
              </li>
              <li class="mb-3 nav-item">
                <a class="nav-link" href="<?php echo e(route('gdpr-policy')); ?>">GDPR Compliance</a>
              </li>
              
            </ul>
          </div>
          <div class="col-12 col-sm-4 mt-6 mt-sm-0 navbar-dark">
          <h5 class="mb-4 text-white">Alternatives</h5>
            <ul class="navbar-nav list-unstyled mb-0">              
              <li class="mb-3 nav-item">
                <a class="nav-link" href="<?php echo e(route('zerobounce-alternative')); ?>">Zerobounce Alternative</a>
              </li>
              <li class="mb-3 nav-item">
                <a class="nav-link" href="<?php echo e(route('neverbounce-alternative')); ?>">NeverBounce Alternative</a>
              </li>
              <li class="mb-3 nav-item">
                <a class="nav-link" href="<?php echo e(route('xverify-alternative')); ?>">Xverify Alternative</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('briteverify-alternative')); ?>">BriteVerify Alternative</a>
              </li>
              
            </ul>
          </div>
        </div>
        <div class="row mt-5">
          <div class="col-12 col-sm-6">
            <a class="footer-logo text-white h2 mb-0" href="<?php echo e(route('front')); ?>">
            Email<span class="fw-bold">Validation</span>
            </a>
          </div>
          <div class="col-12 col-sm-6 mt-6 mt-sm-0">
            <ul class="list-inline mb-0">
              <li class="list-inline-item"><a class="text-light ic-2x" href="#"><i class="la la-facebook"></i></a>
              </li>
              <li class="list-inline-item"><a class="text-light ic-2x" href="#"><i class="la la-dribbble"></i></a>
              </li>
              <li class="list-inline-item"><a class="text-light ic-2x" href="#"><i class="la la-instagram"></i></a>
              </li>
              <li class="list-inline-item"><a class="text-light ic-2x" href="#"><i class="la la-twitter"></i></a>
              </li>
              <li class="list-inline-item"><a class="text-light ic-2x" href="#"><i class="la la-linkedin"></i></a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="row text-white text-center mt-2">
      <div class="col">
      <hr class="mb-2">Copyright <?php echo date("Y"); ?> | All Rights Reserved</div>
    </div>
  </div>
</footer>


<!--footer end-->

</div>

<!-- page wrapper end -->

 
<!--back-to-top start-->

<div class="scroll-top"><a class="smoothscroll" href="#top"><i class="las la-angle-up"></i></a></div>

<!--back-to-top end-->

<!-- inject js start -->

<script src="<?php echo e(asset('assets/front/js/theme-plugin.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/theme-script.js')); ?>"></script>
<?php echo $__env->yieldPushContent('after_scripts'); ?>
<!-- inject js end -->

</body>

</html>
<?php /**PATH C:\wamp64\www\EmailValidation\resources\views/home/layouts/footer.blade.php ENDPATH**/ ?>