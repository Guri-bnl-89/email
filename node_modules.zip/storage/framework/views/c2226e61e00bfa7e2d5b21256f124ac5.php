<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <!-- ** Basic Page Needs ** -->
        <meta charset="utf-8">
        <title><?php echo e(config('app.title')); ?></title>

        <!-- bootstrap.min css -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/front/plugins/bootstrap/bootstrap.min.css')); ?>">
        <!-- Icon Font Css -->

        <link rel="stylesheet" href="<?php echo e(asset('assets/front/plugins/fontawesome/css/all.min.css')); ?>">

        <!-- Main Stylesheet -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/style.css')); ?>">

        <!--Favicon-->
        <link rel="icon" href="<?php echo e(asset('assets/front/images/favicon.png')); ?>" type="image/x-icon">
    </head>

    <body>

        <section class="vh-100 gradient-custom">
            <div class="container py-5 h-100">
                <div class="row d-flex justify-content-center align-items-center h-100">
                    <div class="col-12 col-md-8 col-lg-6 col-xl-5">
                        <div class="card bg-dark text-white" style="border-radius: 1rem;">
                            <div class="card-body p-5 text-center">
                                <div class="mb-md-4 mt-md-4">
                                    <h1 class="mb-2 main-text text-md text-uppercase">
                                    Forgot Your <span>Password?</span>
                                    </h1>
                                    <p class="text-white-50 mb-4">We get it, stuff happens. Just enter your email address below and we'll send you a link to reset your password!</p>

                                    <div class="form-outline form-white mb-4 text-left">
                                        <label class="form-label " for="typeEmailX">Email</label>
                                        <input type="email" id="typeEmailX" class="form-control form-control-lg" />
                                    </div>                                    

                                    <button class="btn btn-main btn-lg px-5 text-sm" type="submit">Reset Password</button>
                                    
                                </div>

                                <div>
                                    <p class="mb-0"><a class="on-link text-white-50" href="">Create an Account!</a></p>
                                    <p class="mb-0">Already have an account? <a href="<?php echo e(route('login')); ?>" class="on-link text-white-50 font-weight-bold">Login!</a></p>
                                    <p class="mb-0"><a class="on-link text-white-50" href="<?php echo e(route('home')); ?>"><i class="btn-icon fa fa-arrow-left ml-2"></i> Back to home</a></p>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


    <!-- 
    Essential Scripts
    =====================================-->
    <!-- Main jQuery -->
    <script src="<?php echo e(asset('assets/front/plugins/jquery/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 4.3.1 -->
    <script src="<?php echo e(asset('assets/front/plugins/bootstrap/bootstrap.min.js')); ?>"></script>

    </body>

</html>
<?php /**PATH C:\wamp64\www\EmailValidation\resources\views/home/forgot_password.blade.php ENDPATH**/ ?>