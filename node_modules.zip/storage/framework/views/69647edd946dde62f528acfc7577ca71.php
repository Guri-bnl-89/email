<?php $__env->startSection('content'); ?>

<!--body content start-->

<div class="page-content">

<!--login start-->

<section>
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-5">
        <div>
        <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
          <div class="text-center mb-5">
            <h2>Forgot your password?</h2>
          <p>Enter your email to reset your password.</p>
          </div>
          <form method="POST" action="<?php echo e(route('password.email')); ?>">
            <?php echo csrf_field(); ?>
            <div class="messages"></div>
            <div class="form-group">
                <label>Email Address</label>
                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email" required autocomplete="email" autofocus>

                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="help-block with-errors"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="btn btn-primary btn-block">
                <?php echo e(__('Send Password Reset Link')); ?>

            </button>
           
           
          </form>
          <div class="mt-4 text-center">
                   <a class="link-title" href="<?php echo e(route('login')); ?>">Back to sign in</a>
                </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!--login end-->

</div>

<!--body content end--> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\EmailValidation\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>