

<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
  <h1>Orders</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
      <li class="breadcrumb-item active">Orders</li>
    </ol>
  </nav>
</div><!-- End Page Title -->

<section class="section">
  <div class="row">
    

    <div class="col-lg-12">

      <div class="card">
        <div class="card-body">

          <div class="d-flex pb-3">
            <div class="card-title p-0 text-start flex-grow-1">Order History</div>
            
          </div>


          <table class="table table-striped text-center" id="orderTable">
            <thead>
              <tr>
                <th scope="col" class="text-center">Order Id</th>
                <th scope="col" class="text-center">Credit In Account</th>
                <th scope="col" class="text-center">Price</th>
                <th scope="col" class="text-center">Discount Price</th>
                <th scope="col" class="text-center">Transaction ID</th>
                <th scope="col" class="text-center">Order Status</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($order->order_id); ?></td>
                <td><?php echo e(number_format($order->credits)); ?></td>
                <td>$<?php echo e($order->price); ?></td>
                <td>$<?php echo e($order->discount_price); ?></td>
                <td><?php echo e($order->transaction_id); ?></td>
                <td><?php echo e(ucfirst($order->status)); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
            </tbody>
          </table>
        </div>
      </div>

    </div>
  </div>
</section>

</main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('cust_scripts'); ?>
  <script>
    $(document).ready(function() {
      // initialized DataTable
      $('#orderTable').DataTable();
    });
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\EmailValidation\resources\views/pages/credit_orders.blade.php ENDPATH**/ ?>