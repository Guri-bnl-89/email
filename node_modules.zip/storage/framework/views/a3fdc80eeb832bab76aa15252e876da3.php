
  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright. All Rights Reserved
    </div>
   
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo e(asset('assets/back/vendor/apexcharts/apexcharts.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/back/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/back/vendor/chart.js/chart.umd.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/back/vendor/echarts/echarts.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/back/vendor/quill/quill.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/back/vendor/simple-datatables/simple-datatables.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/back/vendor/tinymce/tinymce.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/back/vendor/php-email-form/validate.js')); ?>"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo e(asset('assets/back/js/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/back/js/main.js')); ?>"></script>
  <?php echo $__env->yieldPushContent('cust_scripts'); ?>

</body>

</html><?php /**PATH C:\wamp64\www\EmailValidation\resources\views/layouts/footer.blade.php ENDPATH**/ ?>